n = int(input('Digite o valor de n: '))

soma = n* (n+1) //2


print(f'A soma dos {n} primeiros numeros é : {soma}')