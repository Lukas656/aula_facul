for num in range(1, 53):
    print(num)

    if num == 52:
        for num in range(54, 102, 2):
            print(num)